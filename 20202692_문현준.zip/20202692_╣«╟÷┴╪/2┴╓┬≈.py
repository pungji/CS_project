Python 3.11.8 (tags/v3.11.8:db85d51, Feb  6 2024, 22:03:32) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 2+3
5
>>> 511-54
457
>>> 5*15
75
>>> 96/4
24.0
>>> 5*4+4
24
>>> 5*4+6
26
>>> 26+20/2
36.0
>>> (26+20)/2
23.0
>>> hello World
SyntaxError: invalid syntax
>>> SyntaxError: invalid syntax
SyntaxError: invalid syntax
>>> 
>>> 'hello World'
'hello World'
>>> print('hello world')
hello world
