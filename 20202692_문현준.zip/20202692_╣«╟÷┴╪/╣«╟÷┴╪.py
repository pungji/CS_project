print(2+3)
for i in range(5):
    print('hello world')
